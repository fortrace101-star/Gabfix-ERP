import { useEffect, useState } from "react";
import { portalApi } from "@/lib/api";
import { useSession } from "@/lib/session";

/**
 * Live-data layer (plan v5 D1): jobs assigned to the signed-in technician
 * from GET /api/data + lifecycle actions via PATCH /api/jobs/:id/status.
 */

type JobRow = {
  id: string;
  number: string;
  customerId: string | null;
  serviceId: string | null;
  date: string;
  status: string;
  revenue: number;
  cost: number;
  assignees: string[];
};

export type PortalJob = {
  id: string;
  number: string;
  customer: string;
  service: string;
  status: string;
  date: string;
  revenue: number;
  mine: boolean;
};

type AssignmentRow = {
  jobId: string;
  employeeId: string;
  employeeName: string;
  role: string;
  assignedAt: string;
  acceptedAt: string | null;
  completedAt: string | null;
};

/**
 * Role-scoped job feed (plan D5): reads the workspace jobs slice from
 * GET /api/data and, when an employee id is supplied, scopes the result to the
 * jobs that employee is assigned to via `job_assignments` — the join table
 * migration 009 dual-writes alongside the legacy `assignees` text[] column.
 *
 * This replaces the previous name-substring heuristic: Technician's "My jobs"
 * now shows only crew-assigned jobs and the `mine` flag is exact. The optional
 * `employeeId` keeps `useJobOptions` (Timesheets/Costs picker) on the full job
 * list so its most-recent-job preselect stays intact.
 */
export function useMyJobs(employeeName: string | null, employeeId?: string | null) {
  const [jobs, setJobs] = useState<PortalJob[] | null>(null);
  const [error, setError] = useState("");
  const [assignedJobIds, setAssignedJobIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    let alive = true;
    portalApi
      .get<{
        jobs: JobRow[];
        customers: Array<{ id: string; name: string }>;
        services: Array<{ id: string; name: string }>;
        jobAssignments?: AssignmentRow[];
      }>("/data")
      .then((ws) => {
        if (!alive) return;
        const nameOf = (id: string | null) =>
          ws.customers.find((c) => c.id === id)?.name ?? "Customer";
        const serviceOf = (id: string | null) =>
          ws.services.find((s) => s.id === id)?.name ?? "Service";
        const myJobIds = new Set(
          (ws.jobAssignments ?? []).filter((a) => a.employeeId === employeeId).map((a) => a.jobId),
        );
        const mapped: PortalJob[] = ws.jobs.map((row) => ({
          id: row.id,
          number: row.number,
          customer: nameOf(row.customerId),
          service: serviceOf(row.serviceId),
          status: row.status,
          date: row.date,
          revenue: row.revenue,
          mine: myJobIds.has(row.id),
        }));
        setJobs(mapped);
        setAssignedJobIds(myJobIds);
      })
      .catch((e: unknown) => {
        if (alive) setError(e instanceof Error ? e.message : "Failed to load jobs");
      });
    return () => {
      alive = false;
    };
  }, [employeeName, employeeId]);

  return { jobs, error, assignedJobIds };
}

/** Lifecycle transition — the server stamps the timeline (D2). */
export async function setJobStatus(jobId: string, status: string): Promise<void> {
  await portalApi.request(`/jobs/${jobId}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status }),
  });
}

/** SSE subscription: jobs change in any app → refresh here. */
export function subscribeToJobEvents(onChange: () => void): () => void {
  const base = portalApi.baseUrl;
  if (!base || typeof EventSource === "undefined") return () => undefined;
  const token = localStorage.getItem("gabfix:auth-token");
  const url = token ? `${base}/events?access_token=${encodeURIComponent(token)}` : `${base}/events`;
  const es = new EventSource(url);
  for (const type of ["job-created", "job-updated", "workspace-reset"]) {
    es.addEventListener(type, onChange);
  }
  return () => es.close();
}

/**
 * Job options for the filing forms (D3): the signed-in employee's job feed,
 * loaded once in the data layer so the Timesheets and Costs boards share it.
 */
export function useJobOptions(): Array<{ id: string; label: string }> {
  const [options, setOptions] = useState<Array<{ id: string; label: string }>>([]);
  const session = useSession();
  const { jobs } = useMyJobs(session?.name ?? null);

  useEffect(() => {
    setOptions(
      (jobs ?? []).map((job) => ({ id: job.id, label: `${job.number} · ${job.customer}` })),
    );
  }, [jobs]);

  return options;
}
