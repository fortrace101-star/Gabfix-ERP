import { useEffect, useRef, useState } from "react";
import { Bell, CheckCheck, Zap, AlertCircle } from "lucide-react";
import { portalApi } from "@/lib/api";
import {
  canPush,
  requestPushPermission,
  unregisterPush,
  loadVapidKeys,
  saveVapidKeys,
} from "@/lib/push";

/**
 * Bell panel (plan v5 F1/F2) for the employee portal: unread notifications
 * for the signed-in employee — job.assigned rows land here — plus the
 * portal's synthetic app bell. Refreshes live over SSE; uses the portal's
 * native CSS classes (styles.css), not tailwind.
 */

type BellItem = {
  id: string;
  template_key: string;
  entity_type: string;
  entity_id: string;
  status: string;
  payload: Record<string, unknown>;
  created_at: string;
};

type PushConsent = {
  enabled: boolean;
  granted: boolean;
};

const REFRESH_EVENTS = ["notification", "job-created", "job-updated", "workspace-reset"] as const;

export function PortalBell({ employeeId }: { employeeId?: string }) {
  const [items, setItems] = useState<BellItem[]>([]);
  const [connected, setConnected] = useState(false);
  const [open, setOpen] = useState(false);
  const [pushConsent, setPushConsent] = useState<PushConsent>({
    enabled: false,
    granted: false,
  });
  const [pushPermission, setPushPermission] = useState<"prompt" | "granted" | "denied">("prompt");
  const ref = useRef<HTMLDivElement>(null);

  // Load persisted push consent + detect browser push capability.
  useEffect(() => {
    const checkPush = async () => {
      const enabled = localStorage.getItem("gabfix:push:enabled") === "true";
      setPushConsent({ enabled, granted: canPush() });
      const permission = await Notification.permission;
      setPushPermission(permission as "prompt" | "granted" | "denied");
    };
    checkPush();
  }, []);

  // Toggle push consent on/off + request permission on first enable.
  const togglePush = async (enabled: boolean) => {
    if (enabled && !canPush()) {
      setPushConsent((p) => ({ ...p, enabled: true, granted: false }));
      setPushPermission("denied");
      return;
    }
    if (enabled) {
      const permission = await Notification.requestPermission();
      setPushPermission(permission as "prompt" | "granted" | "denied");
      if (permission === "granted") {
        try {
          await requestPushPermission(
            portalApi.baseUrl ?? "",
            "portal",
            () => setPushConsent((p) => ({ ...p, granted: true })),
            () => setPushConsent((p) => ({ ...p, granted: false })),
          );
        } catch {
          setPushConsent((p) => ({ ...p, granted: false }));
        }
      }
    } else {
      try {
        await unregisterPush(portalApi.baseUrl ?? "", "portal");
      } catch {
        /* best-effort */
      }
      setPushConsent((p) => ({ ...p, granted: false }));
    }
    localStorage.setItem("gabfix:push:enabled", String(enabled));
    setPushConsent((p) => ({ ...p, enabled }));
  };

  useEffect(() => {
    let alive = true;
    const fetchItems = () => {
      const base = portalApi.baseUrl;
      if (!base) return;
      const employee = employeeId ? `&employeeId=${encodeURIComponent(employeeId)}` : "";
      portalApi
        .get<BellItem[]>(`/notifications/unread?scope=portal${employee}`)
        .then((rows) => {
          if (alive) setItems(rows);
        })
        .catch(() => {
          /* keep the last list */
        });
    };
    fetchItems();
    const token = localStorage.getItem("gabfix:auth-token");
    const base = portalApi.baseUrl;
    if (!base || typeof EventSource === "undefined") return () => undefined;
    const url = token
      ? `${base}/events?access_token=${encodeURIComponent(token)}`
      : `${base}/events`;
    const es = new EventSource(url);
    es.onopen = () => setConnected(true);
    es.onerror = () => setConnected(false);
    for (const type of REFRESH_EVENTS) es.addEventListener(type, fetchItems);
    return () => {
      alive = false;
      es.close();
    };
  }, [employeeId]);

  useEffect(() => {
    if (!open) return;
    const onClick = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const markRead = async (id: string) => {
    try {
      await portalApi.request(`/notifications/${id}/read`, {
        method: "POST",
        body: JSON.stringify({}),
      });
      setItems((prev) => prev.filter((item) => item.id !== id));
    } catch {
      /* the next SSE event re-syncs */
    }
  };

  const markAll = async () => {
    try {
      await portalApi.request("/notifications/read-all", {
        method: "POST",
        body: JSON.stringify({ scope: "portal", ...(employeeId ? { employeeId } : {}) }),
      });
      setItems([]);
    } catch {
      /* the next SSE event re-syncs */
    }
  };

  const text = (item: BellItem): { title: string; body: string } => {
    const p = item.payload ?? {};
    switch (item.template_key) {
      case "job_assigned":
        return {
          title: "New job assigned",
          body: `${p["job_number"]} — ${p["customer_name"]}${p["scheduled"] ? ` · ${p["scheduled"]}` : ""}${p["address"] ? ` · ${p["address"]}` : ""}`,
        };
      case "job_completion":
        return {
          title: "Job completed",
          body: `${p["customer_name"] ?? "A customer"} — ${p["service_name"] ?? "service"} · balance ${p["balance"] ?? "-"}`,
        };
      case "laundry_ready":
        return {
          title: "Laundry ready",
          body: `${p["customer_name"]}'s order ${p["order_number"]} · UGX ${p["total"]}`,
        };
      case "purchase_approved":
        return {
          title: "Purchase approved",
          body: `${p["item"]} × ${p["qty"]} · UGX ${p["value"]}`,
        };
      default:
        return { title: item.template_key.replace(/_/g, " "), body: "" };
    }
  };

  const age = (iso: string): string => {
    const then = Date.parse(iso);
    if (!Number.isFinite(then)) return "";
    const minutes = Math.max(0, Math.round((Date.now() - then) / 60_000));
    if (minutes < 1) return "just now";
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.round(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.round(hours / 24)}d ago`;
  };

  return (
    <div className="bell-wrap" ref={ref} style={{ position: "relative" }}>
      <button
        type="button"
        aria-label={`Notifications${items.length ? ` (${items.length} unread)` : ""}`}
        className="bell"
        onClick={() => setOpen((value) => !value)}
      >
        <span className="relative inline-flex">
          <Bell />
          {items.length > 0 && (
            <span
              aria-hidden="true"
              className={`absolute ${
                items.length > 9
                  ? "-top-1 -right-1 size-2 rounded-full"
                  : "-top-2 -right-2 grid size-4 place-items-center rounded-full text-[10px] font-bold leading-none"
              } bg-gold`}
            >
              {items.length > 9 ? null : items.length}
            </span>
          )}
        </span>
      </button>
      {open && (
        <div
          style={{
            position: "absolute",
            right: 0,
            top: 44,
            zIndex: 60,
            width: 320,
            background: "var(--surface, #fff)",
            color: "inherit",
            border: "1px solid var(--border, #e5e7eb)",
            borderRadius: 12,
            boxShadow: "0 12px 32px rgba(0,0,0,0.14)",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "10px 16px",
              borderBottom: "1px solid var(--border, #e5e7eb)",
              fontWeight: 600,
              fontSize: 13,
            }}
          >
            <span>Notifications</span>
            <span
              style={{
                display: "flex",
                alignItems: "center",
                gap: 8,
                fontSize: 11,
                fontWeight: 400,
              }}
            >
              <i
                title={connected ? "Live" : "Reconnecting…"}
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: 999,
                  background: connected ? "#10b981" : "var(--muted, #9ca3af)",
                }}
              />
              {items.length > 0 && (
                <button
                  type="button"
                  onClick={() => void markAll()}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    color: "inherit",
                    opacity: 0.7,
                    cursor: "pointer",
                  }}
                >
                  <CheckCheck size={13} /> Mark all read
                </button>
              )}
              {pushConsent.enabled && (
                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    padding: "2px 8px",
                    borderRadius: 999,
                    background: "var(--muted-light, #f3f4f6)",
                    fontSize: 10,
                    color: "var(--muted, #6b7280)",
                  }}
                >
                  <Zap size={11} /> Push live
                </span>
              )}{" "}
              {pushConsent.enabled && pushConsent.granted && (
                <button
                  type="button"
                  onClick={() => void togglePush(false)}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    padding: "2px 8px",
                    borderRadius: 999,
                    background: "#fee2e2",
                    color: "#b91c1c",
                    fontSize: 10,
                    fontWeight: 500,
                    cursor: "pointer",
                  }}
                >
                  <AlertCircle size={11} /> Disable push
                </button>
              )}
            </span>
          </div>
          {pushConsent.enabled && !pushConsent.granted && (
            <div
              style={{
                padding: "10px 16px",
                borderBottom: "1px solid var(--border, #e5e7eb)",
                background: "var(--muted-light, #f9fafb)",
                fontSize: 11,
                color: "var(--muted, #6b7280)",
                display: "flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              <Zap size={11} /> Push is enabled but permission was not granted — notifications will
              not arrive via web push.
            </div>
          )}
          <div style={{ maxHeight: 380, overflowY: "auto" }}>
            {items.length === 0 && (
              <p style={{ padding: "32px 16px", textAlign: "center", fontSize: 13, opacity: 0.6 }}>
                No notifications — jobs assigned to you appear here live.
              </p>
            )}
            {items.map((item) => {
              const { title, body } = text(item);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => void markRead(item.id)}
                  style={{
                    display: "block",
                    width: "100%",
                    textAlign: "left",
                    padding: "12px 16px",
                    borderBottom: "1px solid var(--border, #e5e7eb)",
                    background: "none",
                    color: "inherit",
                    cursor: "pointer",
                  }}
                >
                  <span
                    style={{
                      display: "flex",
                      alignItems: "baseline",
                      justifyContent: "space-between",
                      gap: 8,
                    }}
                  >
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{title}</span>
                    <span style={{ fontSize: 11, opacity: 0.55, flexShrink: 0 }}>
                      {age(item.created_at)}
                    </span>
                  </span>
                  {body && (
                    <span style={{ display: "block", marginTop: 2, fontSize: 12, opacity: 0.65 }}>
                      {body}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
