# Gabfix Portal (In-House ERP)

Technician/staff portal: my jobs (quote → scheduled → started → completed →
invoiced → paid), timesheets, cost capture, and the field beacon (GPS pings to
the admin live map). One of four Gabfix ERP frontends, all backed by the same
Express + PostgreSQL server (`../server`).

## Stack

- React 19 + Vite + TypeScript
- Tailwind CSS v4 (vendored design tokens; dark-mode parity)
- react-router-dom; data access via `src/lib/api.ts` (`portalApi`)
- vite-plugin-pwa (installable, beacon-friendly)

## Development

```sh
npm i
npm run dev        # http://localhost:5175
npm run typecheck
npm run build
```

Copy `.env.example` to `.env`:

```
VITE_API_BASE_URL=http://localhost:5000/api
VITE_APP_ID=portal
```

The server must be running first (`cd ../server && npm run dev`). Every request
is tagged with the `X-App-Id: portal` header and shows up in the server console
as `[portal] GET /api/... 200 12ms`, in `GET /api/logs` (admin-only), and on the
SSE bus at `/api/events`.

## Auth & roles

Staff accounts are created in the Admin Console (owner/manager only) — no
self sign-up. Login goes to `POST /api/auth/login` (canonical contract:
`{accessToken, refreshToken, user: {id, name, role, app_scope}}`); tokens are
held in `localStorage` under `gabfix:auth-token` / `gabfix:refresh-token`. An
employee can only reach this app if their account's `app_scope` includes
`portal`.

The role cheatsheet (authoritative server list in
`server/routes/permission-matrix.ts`):

| Role             | `employees.role` | What they see                                                              |
| ---------------- | ---------------- | -------------------------------------------------------------------------- |
| Owner            | owner            | everything                                                                 |
| Manager          | manager          | app_scope grant/revoke, staff                                              |
| Sales            | sales            | pipeline, quotes, follow-ups                                               |
| Technician       | technician       | my jobs, timesheets, my day                                                |
| Laundry          | laundry          | laundry intake + fulfilment                                                |
| Storekeeper      | storekeeper      | materials, inventory, tools                                                |
| Accountant-field | accountant       | costs, timesheets, expenses                                                |
| CSR              | csr              | the 5-option topbar preview; leads, follow-ups, service requests, feedback |

## Project map

```
src/
├── lib/api.ts       Server API client (X-App-Id, bearer, 401→refresh→retry)
├── lib/filings.ts   My timesheets + cost lines (my-filings, POST /timesheets, /costs)
├── lib/timesheet.ts Kampala-day shift maths for the Timesheets board (pure helpers)
├── lib/costs.ts     Job-cost line maths for the Costs board (pure helpers)
├── lib/portal-data.ts Demo jobs, role copy and demo cost lines (demo-first render)
├── lib/pwa.ts       Service worker registration (prod only)
├── pages/           /auth, / (shell) and the Timesheets + Costs boards (pages/timesheets.tsx, pages/costs.tsx)
└── components/      Vendored UI kit + the shared Modal shell (all CRUD in modals)
```

The sidebar swaps boards **in place** (`active` state in `src/pages/index.tsx`): _My
day_ is the dashboard, while _Timesheets_, _Costs_ and _My trail_ render as full
pages inside `.content`. The Timesheets board is the redesign reference — heading,
KPI strip, Mon–Sun week strip, approval/job/day filters, a sortable table that
becomes stacked cards under 760px, and modal filing with a live hours/value preview.
The Costs board follows the same shell — description/job/day filters, money week
bars, and modal filing whose live preview mirrors the server's pricing rule
(an explicit amount wins over quantity × unit cost).

The Costs board is **demo-first** like the dashboard: until `GET
/api/employees/my-filings` answers its first request, it paints sample lines
from `lib/portal-data.ts` (`demoCostLines()` — KPIs, week bars and table
populated, times clamped to now), and the live ledger takes over the moment
the response lands. An empty ledger shows the empty state (the backend has
the final word); a fetch error keeps the samples visible under the error
note, so the shell still demos without the API.
